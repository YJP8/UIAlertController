//
//  ViewController.h
//  UIAlertView
//
//  Created by YinXun-Yu on 2017/1/6.
//  Copyright © 2017年 YinXun-Yu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)alertView:(UIButton *)sender;

@end

