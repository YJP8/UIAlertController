//
//  ViewController.m
//  UIAlertView
//
//  Created by YinXun-Yu on 2017/1/6.
//  Copyright © 2017年 YinXun-Yu. All rights reserved.
//

#import "ViewController.h"
#import "UIAlertView+Blocks.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)alertView:(UIButton *)sender {
    [[[UIAlertView alloc] initWithTitle:@"提示" message:@"是否需要打印" cancelButtonItem:[JPButtonItem itemWithLabel:@"取消" action:nil] otherButtonItems:[JPButtonItem itemWithLabel:@"是的" action:^{
        NSLog(@"打印");
    }], nil] show];
    
}
@end
