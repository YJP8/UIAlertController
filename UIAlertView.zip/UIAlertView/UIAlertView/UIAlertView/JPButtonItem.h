//
//  JPButtonItem.h
//  Yinxun-Yu
//
//
//  Created by YinXun-Yu on 2017/1/6.
//  Copyright © 2017年 YinXun-Yu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JPButtonItem : NSObject
{
    NSString *label;
    void (^action)();
}
@property (retain, nonatomic) NSString *label;
@property (copy,   nonatomic) void (^action)();
+ (id)item;
+ (id)itemWithLabel:(NSString *)inLabel;
+ (id)itemWithLabel:(NSString *)inLabel action:(void(^)(void))action;
@end

