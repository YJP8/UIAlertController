//
//  JPButtonItem.m
//  Yinxun-Yu
//
//
//  Created by YinXun-Yu on 2017/1/6.
//  Copyright © 2017年 YinXun-Yu. All rights reserved.
//

#import "JPButtonItem.h"

@implementation JPButtonItem
@synthesize label;
@synthesize action;

+ (id)item
{
    return [self new];
}

+ (id)itemWithLabel:(NSString *)inLabel
{
    JPButtonItem *newItem = [self item];
    [newItem setLabel:inLabel];
    return newItem;
}

+ (id)itemWithLabel:(NSString *)inLabel action:(void(^)(void))action
{
  JPButtonItem *newItem = [self itemWithLabel:inLabel];
  [newItem setAction:action];
  return newItem;
}

@end

